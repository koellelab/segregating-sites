import numpy as np
import pandas as pd
from scipy.stats import poisson
import time

import statistics_S
# -----------------
def check_not_extinction(particle, check_where):
    if particle.genotype_count[:, check_where].sum() > 0:
        return 1
    else:
        return 0

def check_there_is_recovered(particle, check_where):
    if particle.genotype_count[:, check_where].sum() > 0:
        return 1
    else:
        return 0

def get_weight_by_s(particles, window_data, sample_class, n_grabs, rng):

    s = np.full(len(particles), np.inf)
    w = np.full(len(particles), np.nan)

    if window_data.size == 0:
        # if there is no data for this window, then weight depends only on extinct flag
        # this likely because we are earlier in the time series than where the data begins
        # or there is a missing data row and we're using homogeneous sampling
        # assumes we've appropriately trimmed empty data rows at the end of the time series
        print('no window data')
        for particle_idx, particle in enumerate(particles):
            last_statevar = particle.statevar[particle.last_idx, :]
            s[particle_idx] = np.nan
            w[particle_idx] = (last_statevar[2:sample_class].sum() > 0).sum()       ## check not extinction


    elif window_data['n'].values[0] == 0:
        for particle_idx, particle in enumerate(particles):
            last_statevar = particle.statevar[particle.last_idx, :]
            s[particle_idx] = np.nan
            w[particle_idx] = (last_statevar[2:sample_class].sum() > 0).sum()       ## check not extinction

    elif window_data['n'].values[0] == 1:
        # if we are within the time series of the data,
        # but n = 1 and s = 0, then weight is determined by having at least 1
        # recovered individual during that windw
        if window_data['s'].values[0] != 0:
            raise Exception("Somethings wrong with the input data: S couldn't be other than 0 if n = 1")

        for particle_idx, particle in enumerate(particles):
            last_statevar = particle.statevar[particle.last_idx, :]
            s[particle_idx] = np.nan
            w[particle_idx] = (last_statevar[sample_class] > 0).sum()       ## check_there_is_recovered

    else:
        # finally, if there is actual data we can evaluate the likelihood
        # print(' > 1 sequence in time window')
        from scipy.stats import poisson
        n_sample_data = int(window_data['n'].values[0])

        t_sampling_1 = 0
        t_sampling_2 = 0
        t_segregating_1 = 0
        t_segregating_2 = 0


        for particle_idx, particle in enumerate(particles):
            segregating_site = []
            sampled_genotype_count = particle.genotype_count[:, sample_class]

            if sampled_genotype_count.sum() < n_sample_data:
                s[particle_idx] = np.nan
                w[particle_idx] = 0
            else:
                for grab_idx in range(n_grabs):
                    start = time.time()
                    chosen_sample_idx = rng.choice(sampled_genotype_count.sum(), size=n_sample_data, replace=False)
                    chosen_sample_genotype = np.digitize(chosen_sample_idx, bins=sampled_genotype_count.cumsum(), right=False)
                    t_sampling_1 += time.time() - start  ##TIMEIT

##                    start = time.time()
##                    hey1 =statistics_S.n_segregating_from_samples(chosen_sample_genotype.astype('int'), particle.genotype_info)
##                    segregating_site.append(hey1)
##                    t_segregating_1 += time.time() - start  ##TIMEIT


                    start = time.time()
                    segregating_site.append(
                        statistics_S.n_segregating_from_samples_faster(chosen_sample_genotype.astype('int'), particle.genotype_info))
                    #hey =
                    #segregating_site.append()
                    t_segregating_2 += time.time() - start  ##TIMEIT


                    #print(f'compare segsite : {hey1:5d} | {hey:5d} | {"v" if hey1 != hey else ""}')

                s[particle_idx] = sum(segregating_site) / n_grabs
                w[particle_idx] = poisson.pmf(window_data['s'], s[particle_idx])

        #w = poisson.pmf(window_data['s'], s)
        if np.isnan(w).any():
            print(s[np.where(np.isnan(w))], w[np.where(np.isnan(w))])
            raise Exception ("w = np.nan")
        w = np.where(np.isnan(w), 0, w)
        print(f"    >> {'t_sampling_1':30s}: {t_sampling_1:>15.7f}")
        print(f"    >> {'t_sampling_2':30s}: {t_sampling_2:>15.7f}")
        print(f"    >> {'t_segregating_1':30s}: {t_segregating_1:>15.7f}")
        print(f"    >> {'t_segregating_2':30s}: {t_segregating_2:>15.7f}")



    return (w, s)


def run_smc (particles, params, imported_data, this_win_idx, this_win_start, this_win_end):
    from operator import add

    t_next_dt_sub_sum = [0]*6       ### TIMEIT
    start = time.time()  ### TIMEIT
    for idx in range(params['n_SMC_particles']):
        particle = particles[idx]
        t_next_dt_sub = params['model_nextdt'](particle, params, this_win_start, this_win_end)       # update_next_dt
        t_update_next_dt = 0  ### TIMEIT

        t_next_dt_sub_sum = list( map(add, t_next_dt_sub_sum, t_next_dt_sub) )

    print(f">> {'update_next_dt':30s} at window {this_win_end:5.2f}: {time.time() - start}")
    print(f"    >> {'t_next_dt_sub_sum':30s}/ {t_next_dt_sub_sum[0]:>15.7f} /{t_next_dt_sub_sum[1]:>15.7f} /{t_next_dt_sub_sum[2]:>15.7f} /{t_next_dt_sub_sum[3]:>15.7f} /{t_next_dt_sub_sum[4]:>15.7f}/{ t_next_dt_sub_sum[5]:>15.7f}")
    #print(f"    >> {'event_count_noninfection':30s}: {t_next_dt_sub_sum[1]:>15.7f}")
    #print(f"    >> {'infection_event_mutate':30s}: {t_next_dt_sub_sum[2]:>15.7f}")
    #print(f"    >> {'t_noninfection_event_update':30s}: {t_next_dt_sub_sum[3]:>15.7f}")
    #print(f"    >> {'infection_event_update':30s}: {t_next_dt_sub_sum[4]:>15.7f}")
    #print(f"    >> {'update_statevar_next':30s}: {t_next_dt_sub_sum[5]:>15.7f}")



    ## get weight by comparing with data
    window_data      = imported_data[imported_data['window_end'] == this_win_end]
    if window_data.size > 0:
        n_sample = [int(window_data['n'].values[0])]
        data_s = window_data['s'].values[0]
    else:
        n_sample = [0]
        data_s = np.nan

    start = time.time()  ### TIMEIT
    this_w_vector, s = \
        get_weight_by_s(particles, window_data, params['sampling_src'], 10,params['rng'])  # default is 50 but we are trying 5
        #get_weight_by_s(particles, window_data, params['sampling_src'], params['n_grabs'], params['rng'])  # default is 50 but we are trying 5
        ### TIMEIT!!!! n_GRAB!!!

    print(f">> {'get_weight_by_s':30s} with s = {data_s:5.2f}: {time.time() - start}")


    ## update n_segregating for each particle
    start = time.time() ### TIMEIT
    for particle_idx, particle in enumerate(particles):
        particle.n_segregating[this_win_idx, 0] = s[particle_idx]
    print(f">> {'copy segregating':30s}: {time.time() - start}")

    return this_w_vector






















