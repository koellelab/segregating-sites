# ------------------
## likelihood.py (SEIR without tranmission heterogeneity)
## last modified : 2021-04-08 by YEONGSEON
# ------------------
import copy
import numpy as np
import pandas as pd
import sys


from SEIR_simple import smc
# ------------------
def calculate (particles, params, imported_data, config):

    params = config.get_event_rate(params)
    params['timeintro'] = params['timestart']

    # get simulation window
    sim_windows = np.arange(max(imported_data['window_end']), params['timeintro'], params['window_dt'] * (-1))  ### corrected 20-08-09
    sim_windows = sim_windows[::-1]

    imported_data = _match_data_and_simwin(imported_data)


    # initialize particles & add n_segregating row if needed
    for particle in particles:
        particle.initiate(params, len(sim_windows))
        particle.n_segregating[:len(sim_windows), -1] = sim_windows


    # matrix for weight, resampling
    w_matrix = np.full([len(sim_windows), params['n_SMC_particles']], np.nan)                 # shape = sim_window * n_SMC_particles
    k_matrix = np.full([len(sim_windows), params['n_SMC_particles']], -9999, 'int')           # shape  = sim_window * n_SMC_particles

    df = None
    # simulate and resample particles for each window
    this_win_start = params['timeintro']
    for this_win_idx in range(len(sim_windows)):

        this_win_end = sim_windows[this_win_idx]
        print("loglikelihood :", (this_win_idx, this_win_start, this_win_end), flush = True)

        this_w_vector, no_introduction, df_tmp = smc.run_smc(particles, params, imported_data, this_win_idx, this_win_start, this_win_end)

        this_w_vector_prod = this_w_vector
        w_matrix[this_win_idx, :] = this_w_vector
        k_matrix[this_win_idx, :] = _resample_particle(np.where(this_w_vector < 0, 0, this_w_vector), params['n_SMC_particles'])

        resample_unique, resample_count = np.unique(k_matrix[this_win_idx, :], return_counts=True)
        resample_repeated_idx_in_unique = np.repeat(resample_unique, repeats=resample_count - 1)

        # save for "particle filtering" ------------------------
        tmp = np.zeros(params['n_SMC_particles'])
        tmp[np.where(np.isin(np.arange(params['n_SMC_particles']), resample_unique))]  = resample_count
        df_tmp['resampled'] = np.repeat(tmp, 2)

        #df_tmp['resampled'] = np.repeat(np.isin(np.arange(params['n_SMC_particles']), k_matrix[this_win_idx, :]), 2)
        if isinstance(df, pd.DataFrame):
            df = pd.concat([df, df_tmp], ignore_index=True)
        else:
            df = df_tmp

        print (np.unique(df.group, return_counts=True)[0][np.where(np.unique(df.group, return_counts=True)[1] != 2)], flush = True)
        df.to_csv(f'{params["out_name"]}_particlelog.tsv', sep="\t", index=False)
        # ------------------------------------------------------

        particles = [particles[idx] for idx in resample_unique] + [copy.deepcopy(particles[idx]) for idx in resample_repeated_idx_in_unique]
        this_win_start = this_win_end



    # calculate overall likelihood - if not "no_introduction"
    data_exists = \
        np.where(np.isin(sim_windows, imported_data[~imported_data['s'].isnull()]['window_end']) == True)[0]

    # replace nans with 0s
    w_matrix = np.where(~(w_matrix >= 0), 0, w_matrix)

    # average likelihoods over particles
    lh = w_matrix[data_exists, :].sum(axis=1) / params['n_SMC_particles']
    print (lh)

    # log likelihood score for this parameter set
    llh = np.log(lh)
    llh_sum = llh.sum()

    print(pd.DataFrame(np.vstack([data_exists, llh]).T, columns=['window', 'llh']).to_string())

    llh = pd.DataFrame(np.vstack([sim_windows[data_exists], llh]).T, columns=['window', 'llh'])


    ## save for particle log
    df.to_csv(f'{params["out_name"]}_particlelog.tsv', sep="\t", index=False)

    ## particle log
    time_points = np.unique(df.t)
    df_final = pd.DataFrame({}, columns=['particle_no', 't', 'S', 'E', 'I', 'R', 'seg'])
    for time_point in time_points:
        df_tmp = pd.DataFrame({}, columns=['particle_no', 't', 'S', 'E', 'I', 'R', 'seg'])
        for idx, particle in enumerate(particles):
            idx_time = np.where(particle.statevar[:, 0] == time_point)[0][0]
            if np.isin(time_point, particle.n_segregating[:, 1]):
                idx_time_ = np.where(particle.n_segregating[:, 1] == time_point)[0][0]
                print(">>", idx_time, idx_time_)
                print (">>>", [idx] + particle.statevar[idx_time, :].tolist() + [particle.n_segregating[idx_time_, 0]])
                df_tmp.loc[idx] = [idx] + particle.statevar[idx_time, :].tolist() + [particle.n_segregating[idx_time_, 0]]

        if isinstance(df_final, pd.DataFrame):
            df_final = pd.concat([df_final, df_tmp], ignore_index=True)
        else:
            df_final = df_tmp

    df_final.to_csv(f'{params["out_name"]}_particlelog_final.tsv', sep="\t", index=False)

    return llh_sum, particles, llh  # abandon t_intro




# ------------------
def _match_data_and_simwin(data):

    data = copy.deepcopy(data)

    data['data_flag'] = np.full_like(data['n'], np.nan)
    before_first_data_point = -1
    between_first_and_last_data_point = 0
    after_last_data_point = 1

    win_intervals = data['window_end']
    n_samples_in_win = data['n']
    sample_point = np.multiply(n_samples_in_win > 0, ~(np.isnan(n_samples_in_win)))
    first_sample_point = win_intervals[sample_point].min()
    last_sample_point = win_intervals[sample_point].max()

    print("first_sample_point:", first_sample_point)
    print("last_sample_point:", last_sample_point)

    data_flag = np.where(win_intervals < first_sample_point, before_first_data_point, data['data_flag'])
    data_flag = np.where(np.multiply(first_sample_point <= win_intervals, win_intervals <= last_sample_point),
                         between_first_and_last_data_point, data_flag)
    data_flag = np.where(last_sample_point < win_intervals, after_last_data_point, data_flag)

    # print (list(zip(n_samples_in_win, data_flag)))
    data['data_flag'] = data_flag

    return data


def _resample_particle (w, n_particle):
    # w = this_w_vector = weight of particles in this window
    # choose particles based on the weight
    if np.sum(w) == 0:
        # when all particles have gone extinct
        # or,  probTajD (in ‘run_SMC_SEIR’) gets evaluated to NaN for all particles,
            # which happens if the model predictions of all particles are exceptionally bad
            # or Tajima’s D can’t effectively be computed from the particles’ simulated data
        k = np.random.randint(low = n_particle, size = n_particle)

    else:
        w_norm = np.array(w) / np.sum(w)  # normalized weight -> now the sum is 1
        k = np.random.choice(range(n_particle), size=n_particle, replace=True, p=w_norm)

    return k
