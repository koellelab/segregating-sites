# ------------------
## smc.py (SEIR without tranmission heterogeneity)
## last modified : 2021-04-08 by YEONGSEON
# ------------------
import numpy as np
import pandas as pd
import sys

#sys.path.append('../')

import statistics_S
import weight

def get_weight_by_s(particles, this_win_end, imported_data, sample_class, n_grabs, rng):

    window_data = imported_data[imported_data['window_end'] == this_win_end]
    first_datapoint = imported_data[imported_data['n'] >= 1]['window_end'].min()

    if window_data.size == 0:
        # if there is no data for this window, then weight depends only on extinct flag
        # this likely because we are earlier in the time series than where the data begins
        # or there is a missing data row and we're using homogeneous sampling
        # assumes we've appropriately trimmed empty data rows at the end of the time series
        print('no window data')
        w = []
        for particle_idx, particle in enumerate(particles):
            t_idx = particle.last_idx
            bool_E_sum_I = (particle.statevar[t_idx, 2] + particle.statevar[t_idx, 3]) > 0

            if bool_E_sum_I == True:
                w.append(1)
            else:
                w.append(0)

        s = np.full(len(particles), np.nan)



    elif window_data['s'].isnull().values[0]:
        # if there is a data row but s but s is nan,
        # s is nan. implies this is a missing data point
        # thus, weight still depends only on extinction
        print('s is null')
        w = []
        for particle_idx, particle in enumerate(particles):
            t_idx = particle.last_idx
            bool_E_sum_I = (particle.statevar[t_idx, 2] + particle.statevar[t_idx, 3]) > 0

            if bool_E_sum_I == True:
                w.append(1)
            else:
                w.append(0)

        s = np.full(len(particles), np.nan)



    elif window_data['n'].values[0] == 1 and window_data['s'].values[0] == 0:
        # if we are within the time series of the data,
        # but n = 1 and s = 0, then weight is determined by having at least 1
        # recovered individual during that windw
        print('only one sequence in time window')
        w = []
        for particle_idx, particle in enumerate(particles):
            t_idx = particle.last_idx
            bool_R = particle.genotype_count[:, -1].sum() > 0

            if bool_R == True:
                w.append(1)
            else:
                w.append(0)

        s = np.full(len(particles), np.nan)




    else:
        # finally, if there is actual data we can evaluate the likelihood
        # print(' > 1 sequence in time window')
        from scipy.stats import poisson
        n_sample_data = int(window_data['n'].values[0])
        s = np.zeros(len(particles))

        for particle_idx, particle in enumerate(particles):
            segregating_site = []
            sampled_genotype_count = particle.genotype_count[:, sample_class]

            if sampled_genotype_count.sum() < n_sample_data:
                s[particle_idx] = np.nan

            else:
                for grab_idx in range(n_grabs):
                    chosen_sample_idx = rng.choice(sampled_genotype_count.sum(), size=n_sample_data, replace=False)
                    chosen_sample_genotype = np.digitize(chosen_sample_idx, bins=sampled_genotype_count.cumsum(), right=False)
                    segregating_site.append(
                        statistics_S.n_segregating_from_samples(chosen_sample_genotype.astype('int'), particle.genotype_info))

                s[particle_idx] = sum(segregating_site) / n_grabs

        w = poisson.pmf(window_data['s'], s)
        w = np.where(np.isnan(w), 0, w)
        print(' > 1 sequence in time window')#, s, window_data['s'])

    # timestart values after earliest datapoint ahve a w of 0
    particle_t0 = np.array([particle.statevar[0, 0] for particle in particles])
    w = np.where(particle_t0 > first_datapoint, 0, w)

    #print ("particle_t0", particle_t0)
    #print ("first_datapoint", first_datapoint)
    print (s, w)

    return (w, s)




def run_smc (particles, params, imported_data, this_win_idx, this_win_start, this_win_end):

    this_w_vector = np.full([params['n_SMC_particles'], params['n_clades']], np.nan)
    no_introduction = False
    all_extinction = True

    window_data = imported_data[imported_data['window_end'] == this_win_end]

    if window_data.size > 0:
        n_sample = [int(window_data['n'].values[0])]
        data_flag = window_data['data_flag'].values[0]
        data_s = window_data['s'].values[0]
    else:
        n_sample = [0]
        data_flag = 0
        data_s = np.nan


    print ("n_sample", data_s)

    df = pd.DataFrame({}, columns=['particle_no', 'group', 't', 'S', 'E', 'I', 'R', 'seg'])
    last_df = []
    curr_df = []
    for idx in range(params['n_SMC_particles']):
        particle = particles[idx]

        # columns = ['particle_no', 'group', 't', 'S', 'E', 'I', 'R', 'seg'])
        group_t  = particle.statevar[particle.last_idx, 0]
        df.loc[idx * 2] = [idx] + [f'{idx}_{group_t}'] + particle.statevar[particle.last_idx].tolist() + [particle.n_segregating[this_win_idx - 1, 0]]

        params['func_update_next_dt'](particle, params, this_win_start, this_win_end)       # update_next_dt

    this_w_vector, s = get_weight_by_s(particles, this_win_end, imported_data, params['idx_g_R'], 50, params['rng'])         # default is 50 but we are trying 5

    for particle_idx, particle in enumerate(particles):
        particle.n_segregating[this_win_idx, 0] = s[particle_idx]

        df.loc[particle_idx*2+1] = [particle_idx] + [f'{particle_idx}_{group_t}'] + particle.statevar[particle.last_idx].tolist() + [particle.n_segregating[this_win_idx, 0]]


    df = df.sort_index()
    print (df, flush=True)

    return this_w_vector, no_introduction, df
