# ------------------
## smc.py (SEIR without tranmission heterogeneity)
## last modified : 2021-04-08 by YEONGSEON
# ------------------
import numpy as np
import sys

#sys.path.append('../')

import statistics_S
import weight
import time

def update_S(particle, n_samples, this_win_idx, R_idx, rng, count_for_mean = 5):

    for clade_idx in range(particle.n_clade):
        n_sample = n_samples[clade_idx]
        clade_R_idx = R_idx[clade_idx]

        segregating_site = []

        if n_sample < 1:    # if there is no sample, we can compute n_segregating
            particle.n_segregating[this_win_idx, clade_idx] = np.nan               # diff. from kk version

        else:
            n_genotype = particle.n_genotype[clade_idx]
            recovered_group = particle.genotype_count[:n_genotype, clade_R_idx]
            genotype_info = particle.genotype_info[:, 2 * clade_idx:2 * (clade_idx+1)]

            if np.sum(recovered_group) < n_sample:
                particle.n_segregating[this_win_idx, clade_idx] = np.nan

            else:
                for i in range(count_for_mean):
                    chosen_sample_idx = rng.choice(recovered_group.sum(), size=n_sample, replace=False)
                    chosen_sample_genotype = np.digitize(chosen_sample_idx, bins=recovered_group.cumsum(), right=False)

                    segregating_site.append(statistics_S.n_segregating_from_samples(chosen_sample_genotype, genotype_info))


                mean_segregating_site = sum(segregating_site) / count_for_mean
                particle.n_segregating[this_win_idx, clade_idx] = mean_segregating_site  # todo


        #return segregating_site
        return





def get_weight_by_s(particles, this_win_end, imported_data, sample_class, n_grabs, rng):

    window_data = imported_data[imported_data['window_end'] == this_win_end]
    first_datapoint = imported_data[imported_data['n'] >= 1]['window_end'].min()

    if window_data.size == 0:
        # if there is no data for this window, then weight depends only on extinct flag
        # this likely because we are earlier in the time series than where the data begins
        # or there is a missing data row and we're using homogeneous sampling
        # assumes we've appropriately trimmed empty data rows at the end of the time series
        print('no window data')
        w = []
        for particle_idx, particle in enumerate(particles):
            t_idx = particle.last_idx
            bool_E_sum_I = (particle.statevar[t_idx, 2] + particle.statevar[t_idx, 3]) > 0

            if bool_E_sum_I == True:
                w.append(1)
            else:
                w.append(1)

        s = np.full(len(particles), np.nan)



    elif window_data['s'].isnull().values[0]:
        # if there is a data row but s but s is nan,
        # s is nan. implies this is a missing data point
        # thus, weight still depends only on extinction
        print('s is null')
        w = []
        for particle_idx, particle in enumerate(particles):
            t_idx = particle.last_idx
            bool_E_sum_I = (particle.statevar[t_idx, 2] + particle.statevar[t_idx, 3]) > 0

            if bool_E_sum_I == True:
                w.append(1)
            else:
                w.append(1)

        s = np.full(len(particles), np.nan)


    elif window_data['n'].values[0] == 1 and window_data['s'].values[0] == 0:
        # if we are within the time series of the data,
        # but n = 1 and s = 0, then weight is determined by having at least 1
        # recovered individual during that windw
        print('only one sequence in time window')
        w = []
        for particle_idx, particle in enumerate(particles):
            t_idx = particle.last_idx
            bool_E_sum_I = (particle.statevar[t_idx, 2] + particle.statevar[t_idx, 3]) > 0

            if bool_E_sum_I == True:
                w.append(1)
            else:
                w.append(0)

        s = np.full(len(particles), np.nan)



    else:
        # finally, if there is actual data we can evaluate the likelihood
        # print(' > 1 sequence in time window')
        from scipy.stats import poisson
        n_sample_data = int(window_data['n'].values[0])
        s = np.zeros(len(particles))

        for particle_idx, particle in enumerate(particles):
            segregating_site = []
            sampled_genotype_count = particle.genotype_count[:, sample_class]

            if sampled_genotype_count.sum() < n_sample_data:
                s[particle_idx] = np.nan

            else:
                for grab_idx in range(n_grabs):
                    chosen_sample_idx = rng.choice(sampled_genotype_count.sum(), size=n_sample_data, replace=False)
                    chosen_sample_genotype = np.digitize(chosen_sample_idx, bins=sampled_genotype_count.cumsum(), right=False)
                    segregating_site.append(
                        statistics_S.n_segregating_from_samples(chosen_sample_genotype.astype('int'), particle.genotype_info))

                s[particle_idx] = sum(segregating_site) / n_grabs

        w = poisson.pmf(window_data['s'], s)
        w = np.where(np.isnan(w), 0, w)
        print(' > 1 sequence in time window')#, s, window_data['s'])

    # timestart values after earliest datapoint ahve a w of 0
    particle_t0 = np.array([particle.statevar[0, 0] for particle in particles])
    w = np.where(particle_t0 > first_datapoint, 0, w)

    #print ("particle_t0", particle_t0)
    #print ("first_datapoint", first_datapoint)
    #print ("w", w)

    return (w, s)




def run_smc (particles, params, imported_data, this_win_idx, this_win_start, this_win_end):

    this_w_vector = np.full([params['n_SMC_particles'], params['n_clades']], np.nan)
    no_introduction = False
    all_extinction = True

    window_data = imported_data[imported_data['window_end'] == this_win_end]

    if window_data.size > 0:
        n_sample = [int(window_data['n'].values[0])]
        data_flag = window_data['data_flag'].values[0]
        data_s = window_data['s'].values[0]
    else:
        n_sample = [0]
        data_flag = 0
        data_s = np.nan


    print ("n_sample", data_s)
    start = time.time()  ### TIMEIT
    t_update_next_dt = 0            ### TIMEIT
    for particle_idx in range(params['n_SMC_particles']):
        particle = particles[particle_idx]
        params['func_update_next_dt'](particle, params, this_win_start, this_win_end)       # update_next_dt
        t_update_next_dt = 0  ### TIMEIT

    print(f">> {'update_next_dt':30s} at window {this_win_end:5.2f}: {time.time() - start}")

    start = time.time()  ### TIMEIT
    this_w_vector, s = get_weight_by_s(particles, this_win_end, imported_data, params['idx_g_R'], 10, params['rng'])         # default is 50 but we are trying 5
    print(f">> {'get_weight_by_s':30s} with s = {data_s:5.2f}: {time.time() - start}")


    for particle_idx, particle in enumerate(particles):
        start = time.time()  ### TIMEIT
        particle.n_segregating[this_win_idx, 0] = s[particle_idx]
        print(f">> {'copy segregating':30s}: {time.time() - start}")



    return this_w_vector, no_introduction, all_extinction
